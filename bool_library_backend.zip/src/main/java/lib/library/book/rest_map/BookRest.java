package lib.library.book.rest_map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RequestMapping(path = "/book")
public interface BookRest {

  @PostMapping(path = "/upload")
  ResponseEntity<String> upload(@RequestBody Map<String, String> requestMap);

  @GetMapping(path = "/view/{id}")
  ResponseEntity<String> view(@PathVariable Integer id);

  @GetMapping(path = "/all_books")
  ResponseEntity<?> viewAll();

  @PutMapping(path = "/update/{id}")
  ResponseEntity<String> updateBookDetails(@RequestBody() Map<String, String> requestMap, @PathVariable Integer id);

  @DeleteMapping(path = "/delete/{id}")
  ResponseEntity<String> deleteBook( @PathVariable Integer id);

}
