package lib.library.book.service;

import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface BookService {
  ResponseEntity<String> upload(Map<String, String> requestMap);

  ResponseEntity<String> view(Integer id);
  ResponseEntity<?> viewAll();

  ResponseEntity<String> updateBookDetails(Map<String, String> requestMap, Integer id);

  ResponseEntity<String> deleteBook( Integer id);
}
