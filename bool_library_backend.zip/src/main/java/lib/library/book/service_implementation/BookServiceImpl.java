package lib.library.book.service_implementation;

import lib.library.book.constants.LibraryConstants;
import lib.library.book.dao.BookDao;
import lib.library.book.entity.Book;
import lib.library.book.service.BookService;
import lib.library.book.utility.LibraryUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Service
public class BookServiceImpl implements BookService {

  private final BookDao bookDao;

  public BookServiceImpl(BookDao bookDao) {
    this.bookDao = bookDao;
  }

  // upload new book
  @Override
  public ResponseEntity<String> upload(Map<String, String> requestMap) {
    try {
      if (validateUploadMap(requestMap)) {
        Book book = bookDao.findBookByTitle(requestMap.get("title"));
        if (Objects.isNull(book)){
          bookDao.save(getBookFromMap(requestMap));
          return LibraryUtility.getResponseEntity("Upload Successful", HttpStatus.OK);
        } else {
          return LibraryUtility.getResponseEntity("Book Title Already Exists", HttpStatus.BAD_REQUEST);
        }
      } else {
        return LibraryUtility.getResponseEntity(LibraryConstants.INVALID_DATA, HttpStatus.BAD_REQUEST);
      }
    } catch (Exception ex) {
      log.info("Error occurred while uploading book!", ex);
    }
    return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  // view book by id
  @Override
  public ResponseEntity<String> view(Integer id) {

    try {
      Book book = bookDao.findBookById(id);
      if (Objects.isNull(book)) {
        return LibraryUtility.getResponseEntity("Book not found", HttpStatus.NOT_FOUND);
      } else {
        return ResponseEntity.ok(book.toString());
      }
    } catch (Exception ex) {
      log.info("Error occurred while retrieving book entry!", ex);
      return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  // method to get all book entries
  @Override
  public ResponseEntity<?> viewAll() {
    try {
      List<Book> books = bookDao.findAll();
      if (books.isEmpty()) {
        return LibraryUtility.getResponseEntity("No books found", HttpStatus.NOT_FOUND);
      } else {


        return ResponseEntity.ok(books);
      }
    } catch (Exception ex) {
      log.info("Error occurred while fetching all products.", ex);
      return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  // update book details method
  @Override
  public ResponseEntity<String> updateBookDetails(Map<String, String> requestMap, Integer id) {
    try {
      if (validateUpdateMap(requestMap)) {
        Book book = bookDao.findBookById(id);
        if (Objects.nonNull(book)) {
          updateBookFromMap(book, requestMap);
          bookDao.save(book);
          return LibraryUtility.getResponseEntity("Update Successful", HttpStatus.OK);
        } else {
          return LibraryUtility.getResponseEntity("Book not found", HttpStatus.NOT_FOUND);
        }
      } else {
        return LibraryUtility.getResponseEntity(LibraryConstants.INVALID_DATA, HttpStatus.BAD_REQUEST);
      }
    } catch (Exception ex) {
      log.info("Error occurred while updating book details.", ex);
      return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  // implement book deletion
  @Override
  public ResponseEntity<String> deleteBook(  Integer id) {
    try {
      Book book = bookDao.findBookById(id);
      if (Objects.nonNull(book)) {
        bookDao.delete(book);
        return LibraryUtility.getResponseEntity("Delete Successful", HttpStatus.OK);
      } else {
        return LibraryUtility.getResponseEntity("Book not found", HttpStatus.NOT_FOUND);
      }
    }
    //exception for failed delete request
    catch (Exception ex) {
      log.info("Error occurred while deleting book!", ex);
      return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  // validate upload request
  private boolean validateUploadMap(Map<String, String> requestMap) {
      try {
        return requestMap.containsKey("title") && requestMap.containsKey("author");
      } catch (Exception ex){
        log.info("Error validating map!");
        return false;
      }
  }

  //  validate the update request
  private boolean validateUpdateMap(Map<String, String> requestMap) {
    return requestMap.containsKey("title") || requestMap.containsKey("author") || requestMap.containsKey("cover_name")
            || requestMap.containsKey("isbn") || requestMap.containsKey("pdf_name");
  }

  //update book with details from the request map
  private void updateBookFromMap(Book book, Map<String, String> requestMap) {
    // set author
    if (requestMap.containsKey("author")){
      book.setAuthor(requestMap.get("author"));
    }
    //set title
    if (requestMap.containsKey("title")){
      book.setTitle(requestMap.get("title"));
    }
    // set optional attributes from map if provided
    getOptionsFromMap(book, requestMap);
  }

  // set optional attributes
  private void getOptionsFromMap(Book book, Map<String, String> requestMap) {
    //set ISBN
    if (requestMap.containsKey("isbn")) {
      book.setIsbn(requestMap.get("isbn"));
    }
  }

  // set book details from map
  private Book getBookFromMap(Map<String, String> requestMap) {
    Book book = new Book();

    // set author
    book.setAuthor(requestMap.get("author"));

    // set title
    book.setTitle(requestMap.get("title"));

    // set optional attributes if provided
    getOptionsFromMap(book, requestMap);
    return book;
  }
}
