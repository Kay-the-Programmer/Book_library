package lib.library.book.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

import java.io.Serializable;

//query to search book by title
@NamedQuery(name = "Book.findBookByTitle", query = "select b from Book b where b.title=:title")

//query to fetch book by id
@NamedQuery(name = "Book.findBookById", query = "select b from Book b where b.id=:id")

//query to fetch all books
@NamedQuery(name = "Book.getAllBooks", query = "select b from Book b")

// automatically generate getter and setter methods
@Data
// mark class as an entity to represent a table in a relational database
@Entity
// generate SQL INSERT statements that only include the columns with non-null values
@DynamicInsert
// generate SQL UPDATE statements that only update the columns whose values have changed
@DynamicUpdate
// assign table name in the database
@Table(name = "books")

public class Book implements Serializable {
  //support serialization for Book objects
  private static final Long serialVersionBID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Integer id;

  @Column(name = "title")
  private String title;

  @Column(name = "author")
  private String author;

  @Column(name = "isbn")
  private String isbn;

}
