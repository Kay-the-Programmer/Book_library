import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';

import {MatFormFieldModule} from "@angular/material/form-field";
import {MatCardModule, MatCardContent, MatCardHeader, MatCardTitleGroup} from "@angular/material/card";
import {MatTooltip} from "@angular/material/tooltip";
import {MatInput} from "@angular/material/input";
import {ReactiveFormsModule} from "@angular/forms";
import { FormsModule} from "@angular/forms";
import { MatLabel} from "@angular/material/form-field";
import {NgOptimizedImage} from "@angular/common";
import {HttpClientModule, HttpClient, withFetch, provideHttpClient} from "@angular/common/http";
import {MatError} from "@angular/material/form-field";
import {BookService} from "./service/book.service";
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import {MatTooltipModule} from "@angular/material/tooltip";

@NgModule({
  declarations: [
    AppComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    MatFormFieldModule,
    MatCardModule,
    MatCardHeader,
    MatCardTitleGroup,
    MatCardContent,
    MatTooltip,
    MatInput,
    ReactiveFormsModule,
    FormsModule,
    MatLabel,
    NgOptimizedImage,
    HttpClientModule,
    MatError,
    MatTooltipModule
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync(),
    provideHttpClient(withFetch()),
    BookService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
