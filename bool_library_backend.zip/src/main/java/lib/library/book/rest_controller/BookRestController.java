package lib.library.book.rest_controller;

import lib.library.book.constants.LibraryConstants;
import lib.library.book.rest_map.BookRest;
import lib.library.book.service.BookService;
import lib.library.book.utility.LibraryUtility;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Slf4j
@RestController

public class BookRestController implements BookRest {

  private final BookService bookService;

  public BookRestController(BookService bookService){
    this.bookService = bookService;
  }
  @Override
  public ResponseEntity<String> upload(Map<String, String> requestMap) {
    try {
      return bookService.upload(requestMap);
    } catch (Exception ex) {
      log.info("Error occurred while accessing book upload service!", ex);
      return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Override
  public ResponseEntity<String> view(Integer id) {
    try {
      return bookService.view(id);
    } catch ( Exception ex){
      log.info("Error occurred while accessing book view service!", ex);
      return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Override
  public ResponseEntity<?> viewAll() {
    try {
      return bookService.viewAll();
    } catch (Exception ex){
      log.info("Error occurred while accessing book view all service!", ex);
      return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Override
  public ResponseEntity<String> updateBookDetails(Map<String, String> requestMap, Integer id) {
    try {
      return bookService.updateBookDetails(requestMap, id);
    } catch (Exception ex) {
      log.info("Error occurred while accessing book update service!", ex);
      return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Override
  public ResponseEntity<String> deleteBook( Integer id ) {
    try {
      return bookService.deleteBook( id);
    } catch (Exception ex) {
      log.info("Error occurred while accessing book delete service!", ex);
      return LibraryUtility.getResponseEntity(LibraryConstants.SOMETHING_WENT_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

}
