export class Book {
  title: string;
  author: string;
  isbn?: string;
  id: number;
}
