import {Injectable} from "@angular/core";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {Book} from "../model/book";
import {map, Observable} from "rxjs";



@Injectable({
  providedIn: 'root'
})
export class BookService{

  constructor(private http:HttpClient) {}



  //add book to database

  allBooks: Book[] = [];

  onBookFetch(){
    this.fetchAllBooks();
  }


  fetchAllBooks(): any  {
    return  this.http.get<{[key: string]: Book}>(
      'http://localhost:8080/book/all_books')
      .pipe(map((response)=>{
        const books = [];
        for (const key in response){
          if (response.hasOwnProperty(key)){
            books.push({...response[key], in: key});
          }
        }
        return books;
      }))


  }

}
