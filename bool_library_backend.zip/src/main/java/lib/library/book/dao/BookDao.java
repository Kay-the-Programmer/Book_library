package lib.library.book.dao;
import lib.library.book.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface BookDao extends JpaRepository<Book, Integer> {
  // find book by id dao
  Book findBookById(@Param("id") Integer id);
  // book by title dao
  Book findBookByTitle(@Param("title") String title);

  // get all books dao
  List<Book> getAllBooks();


}
