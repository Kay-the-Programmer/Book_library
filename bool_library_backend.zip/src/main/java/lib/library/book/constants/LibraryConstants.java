package lib.library.book.constants;

public class LibraryConstants {
  public static final String SOMETHING_WENT_WRONG = "Something Went Wrong";

  public static final String INVALID_DATA = "Invalid Data";
}
