import {Component, OnInit, ViewChild} from '@angular/core';
import {faBook, faEdit, faEye, faPlus, faSync, faTrash} from "@fortawesome/free-solid-svg-icons";
import {BookService} from "./service/book.service";
import {ActivatedRoute} from "@angular/router";
import {Book} from "./model/book";
import {FormBuilder, FormGroup, NgForm, Validators} from "@angular/forms";
import {HttpClient} from "@angular/common/http";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

export class AppComponent implements OnInit{
  title = 'library';
  faBook = faBook;
  faPlus = faPlus;
  faEdit= faEdit;
  faTrash = faTrash;
  faEye = faEye;
  faSync = faSync;
  show= false;
  show_success = false;
  show_error: boolean = false;
  show_delete_success = false;

  update_mode = false;

  update_product_id: number;

  show_book_details= false;

  book_to_view_details: { author: string; isbn: string; title: string };

  @ViewChild('bookForm') form: NgForm ;

  form_text = "New book entry";
  show_update_success: boolean = false;

  constructor( private bookService: BookService, private route: ActivatedRoute, private http: HttpClient, private formBuilder: FormBuilder) {
  }

  allBooks = this.bookService.allBooks;

  fetchBooks(){
    this.bookService.fetchAllBooks() .subscribe((books: Book[])=> {
      console.log(books);
      this.allBooks = books;
    });
  }

  onViewBook( id: number) {
    let oneBook =  this.allBooks.find((book)=> {return  book.id === id});
    console.log(oneBook);
  }

  book_upload: FormGroup = new FormGroup({});

  ngOnInit(): void {
    this.book_upload = this.formBuilder.group({
      title: ["", Validators.required],
      author: ["", Validators.required],
      isbn: [""],
    });
    this.fetchBooks();
    // this.fetchAllBooks();
  }

  onBookUpload(bookDetails: { title: string, author: string, isbn: string }) {
    console.log(bookDetails);
    if (!this.update_mode){
      if (this.book_upload.invalid) {
        return;
      } else {
        this.http.post('http://localhost:8080/book/upload', bookDetails)
          .subscribe(
            (response) => {
              console.log(response);
              this.show_success = true; // Set success flag if response is successful
              this.book_upload.reset();
              this.show = false;
            },
            (error) => {
              console.error(error);
              this.show_error = true;
            }
          );
      }
    } else {
      this.onUpdateBookDetails(this.update_product_id, bookDetails);
    }
  }


  showForm() {
    this.show = !this.show;
    this.update_mode = false;
    this.book_upload.reset();
    this.form_text = "New book entry";
  }


  toggle_success() {
    this.show_success = false;
  }

  toggle_error() {
    this.show_error = false;
  }

  onDeleteBook(id: number) {
    this.http.delete(
      'http://localhost:8080/book/delete/' + id
    )
      .subscribe(
        (response) => {
          console.log(response);
          this.show_delete_success = true;
        }
      ),
      ((error: any) => console.log(error));
  }

  toggle_delete_success() {
    this.show_delete_success = false;
  }

  onEditBook(id: number){
    //get product by id
    let selected_book = this.allBooks.find((book)=>{
      return book.id === id;
    });
    console.log(selected_book);

    this.update_product_id = selected_book.id;

    //show form with book details
    this.show = true
    this.form_text = "Update Book details";

    const bookData = {
      title: selected_book.title,
      author: selected_book.author,
      isbn: selected_book.isbn
    };

    this.book_upload.patchValue(bookData);
    this.update_mode = true;
    console.log(this.book_upload);

  }

  onUpdateBookDetails(id: number, value: { title: string; author: string; isbn: string }){
    this.http.put('http://localhost:8080/book/update/' + id, value)
      .subscribe(() => {
        console.log(value);
        this.show_update_success = true;
        this.book_upload.reset();
        this.show = false;
        this.update_mode = false;
      })
  }

  onViewBookDetail(id: number) {
    this.show_book_details = true;
    let selected_book = this.allBooks.find((book)=>{
      return book.id === id;
    });
    console.log(selected_book);
    this.book_to_view_details = {
      title: selected_book.title,
      isbn: selected_book.isbn,
      author: selected_book.author,

    };

  }

  toggle_update() {
    this.show_update_success = false;
  }

  toggle_details() {
    this.show_book_details = false;
  }
}
